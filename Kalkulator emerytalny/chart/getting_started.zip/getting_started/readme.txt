Thanks for downloading the ZingChart Getting Started template.

Below is information regarding the include template file, index.html

To view the template, open the index.html file in your favorite internet browser. Tada! Interactive charts!

Looking for more information? Visit http://www.zingchart.com/docs for in-depth docs on making the best charts.